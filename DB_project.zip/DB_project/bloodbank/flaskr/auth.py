import functools
from datetime import datetime


from flask import (
    Blueprint, flash, g, redirect, render_template, request, session, url_for
)
from werkzeug.security import check_password_hash, generate_password_hash

from flaskr.db import get_db

bp = Blueprint('auth', __name__, url_prefix='/auth')

def match_donors(blood_type):
    db = get_db() 
    matches = []
    if blood_type == 1:
        rows = db.execute(
            "SELECT first_name, last_name, hospital_name, blood_type FROM patients WHERE need_blood = 'true' AND (blood_type = 1 OR blood_type = 7)"
            ).fetchall()
    elif blood_type == 2:
        rows = db.execute(
            "SELECT first_name, last_name, hospital_name, blood_type FROM patients WHERE need_blood = 'true' AND (blood_type = 1 OR blood_type = 2 OR blood_type = 7 OR blood_type = 8)"
            ).fetchall()
    elif blood_type == 3:
        rows = db.execute(
            "SELECT first_name, last_name, hospital_name, blood_type FROM patients WHERE need_blood = 'true' AND (blood_type = 3 OR blood_type = 7)"
            ).fetchall()
    elif blood_type == 4:
        rows = db.execute(
            "SELECT first_name, last_name, hospital_name, blood_type FROM patients WHERE need_blood = 'true' AND (blood_type = 3 OR blood_type = 4 OR blood_type = 7 OR blood_type = 8)"
            ).fetchall()
    elif blood_type == 5:
        rows = db.execute(
            "SELECT first_name, last_name, hospital_name, blood_type FROM patients WHERE need_blood = 'true' AND (blood_type = 1 OR blood_type = 3 OR blood_type = 5 OR blood_type = 7)"
            ).fetchall()
    elif blood_type == 6:
        rows = db.execute(
            "SELECT first_name, last_name, hospital_name, blood_type FROM patients WHERE need_blood = 'true' AND (blood_type = 1 OR blood_type = 2 OR blood_type = 3 OR blood_type = 4 OR blood_type = 5 OR blood_type = 6 OR blood_type = 7 OR blood_type = 8)"
            ).fetchall()
    elif blood_type == 7:
        rows = db.execute(
            "SELECT first_name, last_name, hospital_name, blood_type FROM patients WHERE need_blood = 'true' AND blood_type = 7"
            ).fetchall()
    else:
        rows = db.execute(
            "SELECT first_name, last_name, hospital_name, blood_type FROM patients WHERE need_blood = 'true' AND (blood_type = 7 OR blood_type = 8)"
            ).fetchall()
    
    for row in rows:
        person_info = []
        person_info.append(row[0])
        person_info.append(row[1])
        person_info.append(row[2])
        person_info.append(row[3])
        matches.append(person_info)

    return matches

def match_recips(blood_type):
    db = get_db() 
    matches = []
    if blood_type == 1:
        rows = db.execute(
            "SELECT first_name, last_name, hospital_name, blood_type FROM patients WHERE need_blood = 'false' AND (blood_type = 1 OR blood_type = 2 OR blood_type = 5 OR blood_type = 6)"
            ).fetchall()
    elif blood_type == 2:
        rows = db.execute(
            "SELECT first_name, last_name, hospital_name, blood_type FROM patients WHERE need_blood = 'false' AND (blood_type = 2 OR blood_type = 6)"
            ).fetchall()
    elif blood_type == 3:
        rows = db.execute(
            "SELECT first_name, last_name, hospital_name, blood_type FROM patients WHERE need_blood = 'false' AND (blood_type = 3 OR blood_type = 4 OR blood_type = 5 OR blood_type = 6)"
            ).fetchall()
    elif blood_type == 4:
        rows = db.execute(
            "SELECT first_name, last_name, hospital_name, blood_type FROM patients WHERE need_blood = 'false' AND (blood_type = 4 OR blood_type = 6)"
            ).fetchall()
    elif blood_type == 5:
        rows = db.execute(
            "SELECT first_name, last_name, hospital_name, blood_type FROM patients WHERE need_blood = 'false' AND (blood_type = 5 OR blood_type = 6)"
            ).fetchall()
    elif blood_type == 6:
        rows = db.execute(
            "SELECT first_name, last_name, hospital_name, blood_type FROM patients WHERE need_blood = 'false' AND blood_type = 6"
            ).fetchall()
    elif blood_type == 7:
        rows = db.execute(
            "SELECT first_name, last_name, hospital_name, blood_type FROM patients WHERE need_blood = 'false' AND (blood_type = 1 OR blood_type = 2 OR blood_type = 3 OR blood_type = 4 OR blood_type = 5 OR blood_type = 6 OR blood_type = 7 OR blood_type = 8)"
            ).fetchall()
    else:
        rows = db.execute(
            "SELECT first_name, last_name, hospital_name, blood_type FROM patients WHERE need_blood = 'false' AND (blood_type = 2 OR blood_type = 4 OR blood_type = 6 OR blood_type = 8)"
            ).fetchall()
    
    for row in rows:
        person_info = []
        person_info.append(row[0])
        person_info.append(row[1])
        person_info.append(row[2])
        person_info.append(row[3])
        matches.append(person_info)

    return matches

@bp.route('/register', methods=('GET', 'POST'))
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        db = get_db()
        error = None

        if username == '':
            error = 'Username is required.'
        elif password == '':
            error = 'Password is required.'
        elif db.execute(
            'SELECT id FROM user WHERE username = ?', (username,)
        ).fetchone() is not None:
            error = 'User {} is already registered.'.format(username)
        
        flash(error)

        if error is None:
            db.execute(
                'INSERT INTO user (username, password) VALUES (?, ?)',
                (username, generate_password_hash(password))
            )
            db.commit()

            return redirect(url_for('auth.first_login'))

        flash(error)

    return render_template('auth/register.html')

@bp.route('/medical_history', methods=('GET', 'POST'))
def med_hist():
    if request.method == 'POST':
        first_name = request.form.get('firstname')
        mid_initial = request.form.get('middleinit')
        last_name = request.form.get('lastname')
        _weight = request.form.get('weight')
        date_of_birth = request.form.get('dateofbirth')
        email = request.form.get('email')
        hospital_name = request.form.get('hospital')
        need_blood = request.form.get('need_blood')
        blood_type = request.form.get('blood_type')
        pregnant = request.form.get('pregnant')
        tattoo = request.form.get('tattoo')
        blood_trans = request.form.get('blood_trans')
        hiv_aids = request.form.get('hiv_aids')
        blood_cancer = request.form.get('blood_cancer')
        last_donation = request.form.get('last_donation')
        user_id = session.get('user_id')

        db = get_db()

        birth_date = datetime.strptime(date_of_birth, "%Y-%m-%d")
        today = datetime.today()
        time_difference = today - birth_date
        age = time_difference.days
        age = int(age)
        age = age/365

        blood_type_dict = {
            'Apos': 1,
            'Aneg': 2,
            'Bpos': 3,
            'Bneg': 4,
            'Opos': 5,
            'Oneg': 6,
            'ABpos': 7,
            'ABneg': 8
        }

        boolean_dict = {
            'No': 'false',
            'Yes': 'true'
        }
       
        bloodType = blood_type_dict.get(blood_type)
        needBlood = boolean_dict.get(need_blood)
        isPregnant = boolean_dict.get(pregnant)
        recentTattoo = boolean_dict.get(tattoo)
        bloodTrans = boolean_dict.get(blood_trans)
        hasHivAids = boolean_dict.get(hiv_aids)
        hasBloodCancer = boolean_dict.get(blood_cancer)
        hasDonated = boolean_dict.get(last_donation)

        if needBlood == 'false' and age < 16:
            return render_template("auth/donor_error.html")
        if int(_weight) < 110 and needBlood == 'false':
            return render_template("auth/donor_error.html")
        if needBlood == 'false' and (isPregnant == 'true' or recentTattoo == 'true' or bloodTrans == 'true' or hasHivAids == 'true' or hasBloodCancer == 'true' or hasDonated == 'true'):
            return render_template("auth/donor_error.html")

        db.execute(
            'INSERT INTO patients (first_name, mid_initial, last_name, weight, date_of_birth, email, blood_type, pregnant, recent_tattoo, blood_transfusion, hiv_aids, blood_cancer, hospital_name, need_blood, last_donation) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', (first_name, mid_initial, last_name, _weight, date_of_birth, email, bloodType, isPregnant, recentTattoo, bloodTrans, hasHivAids, hasBloodCancer, hospital_name, needBlood, hasDonated)
        )
        
        db.commit()

        if needBlood == 'false':
            return render_template('auth/give_blood.html')
            #return redirect(url_for('auth.donor_matches'))
        if needBlood == 'true':
            db.execute(
                'INSERT INTO need_blood (patient_id, blood_type) SELECT patient_id, blood_type FROM patients WHERE patients.first_name = ? and patients.last_name = ? and patients.date_of_birth = ?', (first_name, last_name, date_of_birth)
            )
            db.commit()
            return render_template('auth/need_blood.html')
        db.commit()
    return render_template('auth/med_hist.html')

@bp.route('/first_login', methods=('GET', 'POST'))
def first_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        db = get_db()
        error = None
        user = db.execute(
            'SELECT * FROM user WHERE username = ?', (username,)
        ).fetchone()

        if user is None:
            error = 'Incorrect username.'
        elif not check_password_hash(user['password'], password):
            error = 'Incorrect password.'
        flash(error)

        if error is None:
            session.clear()
            session['user_id'] = user['id']
            return redirect(url_for('auth.med_hist'))

    return render_template('auth/login.html')

@bp.route('/login', methods=('GET', 'POST'))
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        db = get_db()
        error = None
        user = db.execute(
            'SELECT * FROM user WHERE username = ?', (username,)
        ).fetchone()

        if user is None:
            error = 'Incorrect username.'
        elif not check_password_hash(user['password'], password):
            error = 'Incorrect password.'
        flash(error)

        if error is None:
            session.clear()
            session['user_id'] = user['id']
            user_id = session.get('user_id')
            needs_blood = db.execute(
                'SELECT need_blood FROM patients WHERE patient_id = ?', (user_id,)
            ).fetchone()

            need_blood = needs_blood[0]

            if need_blood == 'true':
                return redirect(url_for('auth.recip_matches'))
            else:
                return redirect(url_for('auth.donor_matches'))
                
    return render_template('auth/login.html')

@bp.route('/donor_matches', methods=('GET', 'POST'))
def donor_matches():
    db = get_db() 
    user_id = session.get('user_id')
    blood_type = db.execute(
                'SELECT blood_type FROM patients WHERE patient_id = ?', (user_id,)
            ).fetchone()
    b_type = blood_type[0]
    rows = match_donors(b_type)
    return render_template('auth/donor_matches.html', rows=rows)
    #return render_template('auth/test.html', b_type=b_type)
   

@bp.route('/recip_matches', methods=('GET', 'POST'))
def recip_matches():
    db = get_db() 
    user_id = session.get('user_id')
    blood_type = db.execute(
                'SELECT blood_type FROM patients WHERE patient_id = ?', (user_id,)
            ).fetchone()
    b_type = blood_type[0]
    rows = match_recips(b_type)
    return render_template('auth/recip_matches.html', rows=rows)


@bp.before_app_request
def load_logged_in_user():
    user_id = session.get('id')

    if user_id is None:
        g.user = None
    else:
        g.user = get_db().execute(
            'SELECT * FROM user WHERE id = ?', (id,)
        ).fetchone()

@bp.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('landing'))

def login_required(view):
    @functools.wraps(view)
    def wrapped_view(**kwargs):
        if g.user is None:
            return redirect(url_for('auth.login'))

        return view(**kwargs)

    return wrapped_view
