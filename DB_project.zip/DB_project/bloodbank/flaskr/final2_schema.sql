CREATE TABLE IF NOT EXISTS user (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS patients(
    patient_id INTEGER PRIMARY KEY AUTOINCREMENT,
    first_name TEXT NOT NULL,
    mid_initial TEXT NOT NULL,
    last_name TEXT NOT NULL,
    weight INTEGER,
    date_of_birth  date NOT NULL,
    email TEXT NOT NULL,
    blood_type INTEGER,
    pregnant BOOLEAN NOT NULL,
    recent_tattoo BOOLEAN NOT NULL,
    blood_transfusion BOOLEAN NOT NULL,
    hiv_aids BOOLEAN NOT NULL,
    blood_cancer BOOLEAN NOT NULL,
    hospital_name TEXT NOT NULL,
    need_blood BOOLEAN NOT NULL,
    last_donation BOOLEAN NOT NULL,
    FOREIGN KEY (patient_id) REFERENCES user (id)
);

CREATE TABLE IF NOT EXISTS matched(
    donor_id INTEGER,
    recipient_id INTEGER,
    date_matched TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (donor_id, recipient_id, date_matched),
    FOREIGN KEY (donor_id) REFERENCES patients (patient_id),
    FOREIGN KEY (recipient_id)  REFERENCES patients (patient_id)
);

CREATE TABLE IF NOT EXISTS need_blood(
    date_needed TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    patient_id INTEGER,
    blood_type INTEGER,
    PRIMARY KEY (date_needed, patient_id),
    FOREIGN KEY (patient_id) REFERENCES patients (patient_id),
    FOREIGN KEY (blood_type)  REFERENCES patients (blood_type)
);
